pip uninstall simple-romp
python setup.py install
